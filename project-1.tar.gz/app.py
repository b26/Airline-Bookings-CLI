import os
from methods import *

class App():
    def __init__(self):
        self.choice = None
        self.choosen_flight = []
        self.menu_actions = {
            '1': self.search_flights,
            '3': self.cancel_booking,
            'user_menu': self.user_menu,
            '2': self.listing,
            '4': self.exit_app
            }
    def user_menu(self, connection, email, agent):
        os.system('clear')
        print("====================")
        print("Airline Application")
        print("====================")
        print("Please choose the menu you want to start:")
        print("1 - Search for flights")
        print("2 - List existing bookings")
        print("3 - Cancel a booking")
        if agent:
            print("4 - Agent Departures")
            print("5 - Agent Arrivals")
        print("E - Logout")
        self.choice = input(">> ")
        #self.menu_runner(self.choice)
        if self.choice == "1":
            self.search_flights(connection, email)
        elif self.choice == "2":
            self.listing(connection, email)
        elif self.choice == "3":
            self.cancel_booking(connection, email)
        elif self.choice == "E":
            self.exit_app(connection, email)
        elif self.choice == "4" and agent:
            os.system('clear')
            update(connection, True)
        elif self.choice == "5" and agent:
            os.system('clear')
            update(connection, False)
        else:
            print("invalid choice")
            self.user_menu(connection, email, agent)
    def search_flights(self, connection, email):
        os.system('clear')
        print("===============")
        print("Search Flights")
        print("===============")
        search(connection, self.choosen_flight)
        print(self.choosen_flight)
        if self.choosen_flight == []:
            self.user_menu(connection, email, agent)
        else:
            self.make_booking(connection, email)
        exit()
    def make_booking(self, connection, email):
       os.system('clear')
       print("===============")
       print("Make a booking")
       print("===============")
       booking(connection, self.choosen_flight, email)
       self.user_menu(connection, email, agent)
       exit()
    def listing(self, connection, email):
        os.system('clear')
        print("=======================")
        print("List existing bookings")
        print("=======================")
        list_bookings(connection, email)
        self.user_menu(connection, email, agent)
        #exit()
    def cancel_booking(self, connection, email):
        os.system('clear')
        print("=================")
        print("Cancel a Booking")
        print("=================")
        cancel_booking(connection, email)
        self.user_menu(connection, email, agent)
        #exit()
    def exit_app(self, connection, email):
        os.system('clear')
        logout(connection, email)
        exit()

