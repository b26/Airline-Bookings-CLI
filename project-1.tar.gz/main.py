import sys
import cx_Oracle
import getpass
import os
from creds import *
import datetime
from methods import *
import datetime
from app import App
import time
#get user
#user = input("Username [%s]: " % getpass.getuser())
#if not user:
   # user = getpass.getuser()

#get password
#password = getpass.getpass()
#connection string
os.system('clear')
connection_string = ''+user+'/'+password+'@gwynne.cs.ualberta.ca:1521/CRS'

choosen_flight = []
test_email = "bashir1@ualberta.ca"
test_name = "Bashir Osman"
agent = False
try:
    connection = cx_Oracle.connect(connection_string)
    app = App()
    print("====================")
    print("Airline Application")
    print("====================")
    print("1 - Login")
    print("2 - Register")
    print("3 - Exit")
    choice = input(">> ")
    if choice == "1":
        email = input("Email [%s]: " % getpass.getuser())
        password = getpass.getpass()
        cursor = connection.cursor()
        query = "select * from users where email = '%s' and pass = '%s'" % (email, password)
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()
        if len(rows) == 0:
            print("Incorrect password or email")
            exit()
        else:
            cursor = connection.cursor()
            query = "select * from airline_agents where email = '%s'" % (email)
            cursor.execute(query)
            rows = cursor.fetchall()
            if rows == []:
                agent = False
            else:
                agent = True
            app.user_menu(connection, email, agent)
    elif choice == "2":
        email = input("Email: ")
        password = getpass.getpass()
        date = datetime.datetime.today()
        data = [(email, password, date)]
        cursor = connection.cursor()
        query = "insert into users(email, pass, last_login) values(:1, :2, :3)"
        cursor.executemany(query, data)
        connection.commit()
        app.user_menu(connection, email, agent)
    else:
        exit()
    connection.close()
except cx_Oracle.DatabaseError as exc:
    error, = exc.args
    if error.code == 955:
        print("Table already exists")
    elif error.code == 1017:
        print("Invalid Credentials")
    else:
        print(sys.stderr, "Oracle code: ", error.code)
        print(sys.stderr, "Oracle message: ", error.message)





